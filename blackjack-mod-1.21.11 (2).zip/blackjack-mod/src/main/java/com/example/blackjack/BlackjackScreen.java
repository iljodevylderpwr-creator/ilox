package com.example.blackjack;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class BlackjackScreen extends Screen {
    private static final int W = 300, H = 200;
    private static final int CARD_W = 24, CARD_H = 34;

    private StatePayload state;
    private final List<ButtonWidget> buttons = new ArrayList<>();
    private ButtonWidget hostHit, hostStand, oppHit, oppStand;

    public BlackjackScreen(StatePayload state) {
        super(Text.literal("Blackjack"));
        this.state = state;
    }

    private int left() { return (width - W) / 2; }
    private int top() { return (height - H) / 2; }

    private ButtonWidget makeButton(String label, int x, int y, int w, ButtonWidget.PressAction action) {
        ButtonWidget b = ButtonWidget.builder(Text.literal(label), action).dimensions(x, y, w, 18).build();
        addSelectableChild(b); // handles clicks; we draw it ourselves in render()
        buttons.add(b);
        return b;
    }

    @Override
    protected void init() {
        buttons.clear();
        int l = left(), t = top();
        hostHit = makeButton("Hit", l + W - 112, t + 19, 50, b -> send(0));
        hostStand = makeButton("Stand", l + W - 58, t + 19, 50, b -> send(1));
        oppHit = makeButton("Hit", l + W - 112, t + 87, 50, b -> send(0));
        oppStand = makeButton("Stand", l + W - 58, t + 87, 50, b -> send(1));
        makeButton("Close", l + W / 2 - 30, t + H - 26, 60, b -> close());
        refresh();
    }

    public void update(StatePayload newState) {
        this.state = newState;
        refresh();
    }

    private void refresh() {
        if (hostHit == null) return;
        boolean hostActive = !state.over() && state.seat() == 0 && state.turn() == 0;
        boolean oppActive = !state.over() && state.seat() == 1 && state.turn() == 1;
        hostHit.active = hostActive;
        hostStand.active = hostActive;
        oppHit.active = oppActive;
        oppStand.active = oppActive;
    }

    private void send(int action) {
        ClientPlayNetworking.send(new ActionPayload(action));
    }

    // Must not pause: in singleplayer a paused server would never process Hit/Stand.
    @Override
    public boolean shouldPause() {
        return false;
    }

    private void border(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void centered(DrawContext ctx, String s, int cx, int y, int color, boolean shadow) {
        ctx.drawText(textRenderer, Text.literal(s), cx - textRenderer.getWidth(s) / 2, y, color, shadow);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // vanilla background

        int l = left(), t = top();
        ctx.fill(l, t, l + W, t + H, 0xEE1B5E20);
        border(ctx, l, t, W, H, 0xFFFFD54F);
        centered(ctx, "BLACKJACK", width / 2, t + 6, 0xFFFFD54F, true);

        drawHand(ctx, l + 10, t + 24, state.hostName(), "Host", 0, state.hostCards());
        drawHand(ctx, l + 10, t + 92, state.oppName(),
                state.oppName().equals("Dealer") ? "" : "Player", 1, state.oppCards());

        int color = state.over() ? 0xFFFFD54F : 0xFFFFFFFF;
        String msg = state.over() ? state.message()
                : (state.turn() == state.seat() ? "Your turn - Hit or Stand?" : "Waiting for the other side...");
        centered(ctx, msg, width / 2, t + 154, color, true);

        for (ButtonWidget b : buttons) b.render(ctx, mouseX, mouseY, delta);
    }

    private void drawHand(DrawContext ctx, int x, int y, String name, String role, int seat, List<Integer> cards) {
        int total = BlackjackGame.total(cards);
        boolean turn = state.turn() == seat;
        StringBuilder label = new StringBuilder(name);
        if (!role.isEmpty()) label.append(" (").append(role).append(")");
        if (state.seat() == seat) label.append(" *");
        label.append(" [").append(total).append("]");
        if (total > 21) label.append(" BUST");
        ctx.drawText(textRenderer, Text.literal(label.toString()), x, y + 1,
                turn ? 0xFFFFEB3B : 0xFFFFFFFF, true);

        int n = cards.size();
        int step = n <= 1 ? 28 : Math.min(28, (W - 20 - CARD_W) / (n - 1));
        for (int i = 0; i < n; i++) {
            int cx = x + i * step, cy = y + 18;
            int v = cards.get(i);
            String s = v == 1 ? "A" : String.valueOf(v);
            ctx.fill(cx, cy, cx + CARD_W, cy + CARD_H, 0xFFF5F5F5);
            border(ctx, cx, cy, CARD_W, CARD_H, 0xFF000000);
            ctx.drawText(textRenderer, Text.literal(s), cx + (CARD_W - textRenderer.getWidth(s)) / 2,
                    cy + 13, v == 1 ? 0xFFC62828 : 0xFF000000, false);
        }
    }
}
