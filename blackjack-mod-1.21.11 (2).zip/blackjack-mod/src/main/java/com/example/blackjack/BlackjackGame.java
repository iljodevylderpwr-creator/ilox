package com.example.blackjack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** Server-side game state. Cards are 1 (Ace) through 10. Seat 0 = host, seat 1 = player/dealer. */
public class BlackjackGame {
    private static final Random RNG = new Random();

    public final UUID hostId;
    public final UUID oppId; // null => the opponent is the automated Dealer
    public final String hostName;
    public final String oppName;
    public final List<Integer> hostCards = new ArrayList<>();
    public final List<Integer> oppCards = new ArrayList<>();
    public int turn = 0;       // 0 = host, 1 = opponent, -1 = round finished
    public boolean over = false;
    public String message = "";

    public BlackjackGame(UUID hostId, String hostName, UUID oppId, String oppName) {
        this.hostId = hostId;
        this.hostName = hostName;
        this.oppId = oppId;
        this.oppName = oppName;
        hostCards.add(draw());
        hostCards.add(draw());
        oppCards.add(draw());
        oppCards.add(draw());
        if (total(hostCards) >= 21) advance();
    }

    public boolean isDealer() {
        return oppId == null;
    }

    private static int draw() {
        return RNG.nextInt(10) + 1; // 1..10
    }

    /** Ace counts as 11 when that doesn't bust the hand, otherwise 1. */
    public static int total(List<Integer> cards) {
        int sum = 0;
        boolean ace = false;
        for (int c : cards) {
            sum += c;
            if (c == 1) ace = true;
        }
        return (ace && sum + 10 <= 21) ? sum + 10 : sum;
    }

    public void hit(int seat) {
        if (over || seat != turn) return;
        List<Integer> hand = seat == 0 ? hostCards : oppCards;
        hand.add(draw());
        if (total(hand) >= 21) advance();
    }

    public void stand(int seat) {
        if (over || seat != turn) return;
        advance();
    }

    private void advance() {
        if (turn == 0) {
            turn = 1;
            if (isDealer()) {
                while (total(hostCards) <= 21 && total(oppCards) < 17) oppCards.add(draw());
                finish();
            } else if (total(oppCards) >= 21) {
                finish();
            }
        } else {
            finish();
        }
    }

    private void finish() {
        over = true;
        turn = -1;
        int h = total(hostCards), o = total(oppCards);
        if (h > 21 && o > 21) message = "Both bust - draw!";
        else if (h > 21) message = oppName + " wins! (" + hostName + " busted)";
        else if (o > 21) message = hostName + " wins! (" + oppName + " busted)";
        else if (h > o) message = hostName + " wins, " + h + " to " + o + "!";
        else if (o > h) message = oppName + " wins, " + o + " to " + h + "!";
        else message = "Push - both have " + h + ".";
    }
}
