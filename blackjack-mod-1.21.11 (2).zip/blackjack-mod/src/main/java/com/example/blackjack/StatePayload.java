package com.example.blackjack;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client: full snapshot of the game. {@code seat} says which seat the receiver occupies. */
public record StatePayload(int seat, String hostName, String oppName,
                           List<Integer> hostCards, List<Integer> oppCards,
                           int turn, boolean over, String message) implements CustomPayload {

    public static final Id<StatePayload> ID = new Id<>(Identifier.of(BlackjackMod.MOD_ID, "state"));
    public static final PacketCodec<PacketByteBuf, StatePayload> CODEC =
            PacketCodec.of(StatePayload::write, StatePayload::read);

    private static StatePayload read(PacketByteBuf b) {
        return new StatePayload(b.readVarInt(), b.readString(), b.readString(),
                readList(b), readList(b), b.readVarInt(), b.readBoolean(), b.readString());
    }

    private void write(PacketByteBuf b) {
        b.writeVarInt(seat);
        b.writeString(hostName);
        b.writeString(oppName);
        writeList(b, hostCards);
        writeList(b, oppCards);
        b.writeVarInt(turn);
        b.writeBoolean(over);
        b.writeString(message);
    }

    private static List<Integer> readList(PacketByteBuf b) {
        int n = b.readVarInt();
        List<Integer> l = new ArrayList<>(n);
        for (int i = 0; i < n; i++) l.add(b.readVarInt());
        return l;
    }

    private static void writeList(PacketByteBuf b, List<Integer> l) {
        b.writeVarInt(l.size());
        for (int i : l) b.writeVarInt(i);
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
