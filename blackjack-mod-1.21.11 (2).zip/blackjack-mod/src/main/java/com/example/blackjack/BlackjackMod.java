package com.example.blackjack;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class BlackjackMod implements ModInitializer {
    public static final String MOD_ID = "blackjack";

    /** Each participant's UUID maps to the game they are in. */
    private static final Map<UUID, BlackjackGame> GAMES = new HashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);

        // /bj            -> host vs. dealer (or re-open your current game)
        // /bj <player>   -> host vs. another player
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
                dispatcher.register(CommandManager.literal("bj")
                        .executes(ctx -> start(ctx.getSource(), null))
                        .then(CommandManager.argument("player", EntityArgumentType.player())
                                .executes(ctx -> start(ctx.getSource(),
                                        EntityArgumentType.getPlayer(ctx, "player"))))));

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            BlackjackGame g = GAMES.get(p.getUuid());
            if (g == null) return;
            int seat = p.getUuid().equals(g.hostId) ? 0 : 1;
            if (payload.action() == 0) g.hit(seat);
            else g.stand(seat);
            sync(g, context.server());
            if (g.over) end(g);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.getPlayer().getUuid();
            BlackjackGame g = GAMES.get(id);
            if (g == null) return;
            end(g);
            UUID otherId = id.equals(g.hostId) ? g.oppId : g.hostId;
            if (otherId != null) {
                ServerPlayerEntity other = server.getPlayerManager().getPlayer(otherId);
                if (other != null) {
                    other.sendMessage(Text.literal("Blackjack cancelled: your opponent left."), false);
                }
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> GAMES.clear());
    }

    private static int start(ServerCommandSource src, ServerPlayerEntity target) throws CommandSyntaxException {
        ServerPlayerEntity host = src.getPlayerOrThrow();
        MinecraftServer server = src.getServer();

        BlackjackGame existing = GAMES.get(host.getUuid());
        if (existing != null) { // re-open the GUI if it was closed
            sync(existing, server);
            return 1;
        }

        if (target != null) {
            if (target.getUuid().equals(host.getUuid())) {
                src.sendError(Text.literal("You can't play blackjack against yourself."));
                return 0;
            }
            if (GAMES.containsKey(target.getUuid())) {
                src.sendError(Text.literal(target.getName().getString() + " is already in a blackjack game."));
                return 0;
            }
        }

        String hostName = host.getName().getString();
        BlackjackGame g = target == null
                ? new BlackjackGame(host.getUuid(), hostName, null, "Dealer")
                : new BlackjackGame(host.getUuid(), hostName, target.getUuid(), target.getName().getString());

        GAMES.put(host.getUuid(), g);
        if (target != null) {
            GAMES.put(target.getUuid(), g);
            target.sendMessage(Text.literal(hostName + " started a blackjack game with you!"), false);
        }

        sync(g, server);
        if (g.over) end(g);
        return 1;
    }

    private static void sync(BlackjackGame g, MinecraftServer server) {
        ServerPlayerEntity host = server.getPlayerManager().getPlayer(g.hostId);
        if (host != null) send(host, g, 0);
        if (!g.isDealer()) {
            ServerPlayerEntity opp = server.getPlayerManager().getPlayer(g.oppId);
            if (opp != null) send(opp, g, 1);
        }
    }

    private static void send(ServerPlayerEntity p, BlackjackGame g, int seat) {
        ServerPlayNetworking.send(p, new StatePayload(seat, g.hostName, g.oppName,
                new ArrayList<>(g.hostCards), new ArrayList<>(g.oppCards), g.turn, g.over, g.message));
    }

    private static void end(BlackjackGame g) {
        GAMES.remove(g.hostId);
        if (g.oppId != null) GAMES.remove(g.oppId);
    }
}
