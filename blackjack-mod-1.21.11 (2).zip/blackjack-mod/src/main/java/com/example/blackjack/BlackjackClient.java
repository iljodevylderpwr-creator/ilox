package com.example.blackjack;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;

public class BlackjackClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(StatePayload.ID, (payload, context) -> {
            MinecraftClient mc = context.client();
            if (mc.currentScreen instanceof BlackjackScreen screen) {
                screen.update(payload);
            } else {
                mc.setScreen(new BlackjackScreen(payload));
            }
        });
    }
}
